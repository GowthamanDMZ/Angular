import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashBoardComponent } from './dash-board/dash-board.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LoginformComponent } from './loginform/loginform.component';

const routes: Routes = [
  {
    path: 'dashboard',
    component : DashBoardComponent
  },
  {
    path: '',
    component : HomeComponent
  },
  {
    path: 'login',
    component : LoginComponent
  },
  {
    path: 'loginform',
    component : LoginformComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

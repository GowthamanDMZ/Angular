import { BluecoloredDirective } from './bluecolored.directive';

describe('BluecoloredDirective', () => {
  it('should create an instance', () => {
    const directive = new BluecoloredDirective();
    expect(directive).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  title = 'helloWorldApp';
  visible = true;
  counter = 0;
  textResult = "";
  testObj = {
    'uiLang' : ['html','css','javascript'],
    'backendLang' : ['java','python','.net']
  };
  bindResult = "newString";
  testArray = [
    {'name' : 'html', 'type':'uiLang'},
    {'name' : 'java', 'type':'backendLang'},
    {'name' : 'javascript', 'type':'uiLang'},
    {'name' : 'python', 'type':'backendLang'}
  ];

  toggleDiv(){
    this.visible = !this.visible;
  }

  startCounter(){
    this.counter++;
  }

  myFunction(event){
    console.log("my function called"+event.target.value);
    this.textResult = this.textResult+ event.target.value +'\n';
  }

  newFunction(ev){
    console.log("newFunction called:" + ev);
    console.log("value:" + ev.target.value);
  }

}
